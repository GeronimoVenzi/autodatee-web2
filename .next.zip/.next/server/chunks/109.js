exports.id = 109;
exports.ids = [109];
exports.modules = {

/***/ 7802:
/***/ ((module) => {

// Exports
module.exports = {
	"footer__container": "FooterPage_footer__container__1MCcI",
	"font__mont__alt": "FooterPage_font__mont__alt___GkrQ",
	"footer__container__icons": "FooterPage_footer__container__icons__owPIg"
};


/***/ }),

/***/ 7467:
/***/ ((module) => {

// Exports
module.exports = {
	"bg_form": "FormPage_bg_form__6lXBN",
	"form__title": "FormPage_form__title__7wNLg",
	"form__btn": "FormPage_form__btn__Z3_lb",
	"form__group": "FormPage_form__group__xDe3V",
	"form__textarea": "FormPage_form__textarea__S2pHp",
	"form__group__input": "FormPage_form__group__input__JpumW"
};


/***/ }),

/***/ 4453:
/***/ ((module) => {

// Exports
module.exports = {
	"nav_burger": "Navbar_nav_burger__RZmeO",
	"nav_bar": "Navbar_nav_bar__QfrdW",
	"nav_link_text": "Navbar_nav_link_text__lW3jW",
	"nav_title": "Navbar_nav_title__pgqjp"
};


/***/ }),

/***/ 6109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "A": () => (/* reexport */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: external "react-bootstrap/Form"
var Form_ = __webpack_require__(5226);
var Form_default = /*#__PURE__*/__webpack_require__.n(Form_);
// EXTERNAL MODULE: ./components/FormPage/FormPage.module.css
var FormPage_module = __webpack_require__(7467);
var FormPage_module_default = /*#__PURE__*/__webpack_require__.n(FormPage_module);
;// CONCATENATED MODULE: ./components/FormPage/FormPage.jsx




const FormPage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "section__container",
        id: "contacto",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: (FormPage_module_default()).form__title,
                    children: "Contactanos"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Form_default()), {
                className: `${(FormPage_module_default()).bg_form} container mb-5 mt-5 font__mont`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (FormPage_module_default()).form__group,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Group, {
                                        className: `${(FormPage_module_default()).form__group__input} mb-5`,
                                        controlId: "formBasicName",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
                                            type: "name",
                                            placeholder: "Nombre"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Group, {
                                        className: `${(FormPage_module_default()).form__group__input} mb-5`,
                                        controlId: "formBasicPhone",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
                                            type: "number",
                                            placeholder: "Telefono"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Group, {
                                        className: `${(FormPage_module_default()).form__group__input} mb-5`,
                                        controlId: "formBasicEmail",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
                                            type: "email",
                                            placeholder: "E-mail"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Group, {
                                        className: `${(FormPage_module_default()).form__group__input} mb-5`,
                                        controlId: "formBasicRole",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
                                            type: "text",
                                            placeholder: "Selecciona un rol"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `${(FormPage_module_default()).form__textarea}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.FloatingLabel, {
                            className: "mb-5",
                            controlId: "floatingTextarea2",
                            label: "Contanos de tu proyecto",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Form_default()).Control, {
                                as: "textarea",
                                style: {
                                    height: "250px"
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "d-flex justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${(FormPage_module_default()).form__btn} btn btn-outline-light`,
                            type: "submit",
                            children: "Enviar"
                        })
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/FormPage/index.js


// EXTERNAL MODULE: ./components/FooterPage/FooterPage.module.css
var FooterPage_module = __webpack_require__(7802);
var FooterPage_module_default = /*#__PURE__*/__webpack_require__.n(FooterPage_module);
;// CONCATENATED MODULE: ./components/FooterPage/FooterPage.jsx


const FooterPage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (FooterPage_module_default()).footer__container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `${(FooterPage_module_default()).font__mont__alt}`,
                    children: " \xa9 2020 All rights reserved."
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (FooterPage_module_default()).footer__container__icons,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-instagram"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-twitter"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-youtube"
                        })
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/FooterPage/index.js


// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-bootstrap/Offcanvas"
var Offcanvas_ = __webpack_require__(6865);
var Offcanvas_default = /*#__PURE__*/__webpack_require__.n(Offcanvas_);
// EXTERNAL MODULE: external "react-bootstrap/Container"
var Container_ = __webpack_require__(4678);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_);
// EXTERNAL MODULE: external "react-bootstrap/Nav"
var Nav_ = __webpack_require__(2540);
var Nav_default = /*#__PURE__*/__webpack_require__.n(Nav_);
// EXTERNAL MODULE: external "react-bootstrap/Navbar"
var Navbar_ = __webpack_require__(4934);
var Navbar_default = /*#__PURE__*/__webpack_require__.n(Navbar_);
;// CONCATENATED MODULE: ./components/assets/Logos/AD-logo.png
/* harmony default export */ const AD_logo = ({"src":"/_next/static/media/AD-logo.fe47ed9c.png","height":172,"width":243,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAv0lEQVR42mMAgRiNIrYYhbxAEDtSpTAoSq1wYaRBmSYDDIQpF1qHqRX9D1ErNk5kTVaOYU5vjxDIPmLVvN2OAQQ8LRtne5o3nPI2q79v5z3Bn6HtmKFV+fqVDhkL5zGo6TWr6PpMOs6YvprHyHPCJ2et2hSQJrWcldMNPCfMZhAr2TiXP3dNB0iQL3vVbKHKrctEmvZmiWQsP8ccM9+QQW7SyQjl2RdkQQqUZ55XlOs/tkC269Bsmd5jOgwMDAwArks9krhF/+oAAAAASUVORK5CYII="});
// EXTERNAL MODULE: ./components/Navbar/Navbar.module.css
var Navbar_module = __webpack_require__(4453);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
;// CONCATENATED MODULE: ./components/Navbar/Navbar.jsx










const NavBar = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()), {
            className: (Navbar_module_default()).nav_bar,
            bg: "light",
            expand: "true",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                fluid: true,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()).Brand, {
                        className: (Navbar_module_default()).nav_title,
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: AD_logo,
                            width: "65",
                            height: "45",
                            className: "d-inline-block align-top",
                            alt: "Autodatee logo"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()).Toggle, {
                        className: (Navbar_module_default()).nav_burger
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Navbar_default()).Offcanvas, {
                        id: `offcanvasNavbar-expand`,
                        "aria-labelledby": `offcanvasNavbarLabel-expand`,
                        placement: "end",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Offcanvas_default()).Header, {
                                closeButton: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Offcanvas_default()).Title, {
                                    id: `offcanvasNavbarLabel-expand`,
                                    className: (Navbar_module_default()).nav_link_text,
                                    children: "Menu"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Offcanvas_default()).Body, {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()), {
                                    className: `${(Navbar_module_default()).nav_link_text}
                justify-content-end
                flex-grow-1
                pe-3
                `,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/#inicio",
                                            children: "Home"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/#nosotros",
                                            children: "Sobre nosotros"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.NavDropdown, {
                                            title: "Servicios",
                                            id: `offcanvasNavbarDropdown-expand`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.NavDropdown.ItemText, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/estrategia",
                                                        children: "Estrategia"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.NavDropdown.ItemText, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/creatividad",
                                                        children: "Creatividad y Contenidos"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.NavDropdown.ItemText, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/relaciones",
                                                        children: "Relaciones P\xfablicas"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.NavDropdown.ItemText, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/social",
                                                        children: "Social Media"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.NavDropdown.ItemText, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/gestion",
                                                        children: "Gesti\xf3n de Crisis"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.NavDropdown.ItemText, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/leads",
                                                        children: "Generaci\xf3n de Leads"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#contacto",
                                            children: "Contactanos"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./components/Navbar/index.js


;// CONCATENATED MODULE: ./components/Layout/Layout.jsx





const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Autodatee Web"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet",
                        href: "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.googleapis.com"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com",
                        crossOrigin: true
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NavBar, {}),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(FormPage, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(FooterPage, {})
        ]
    });
};

;// CONCATENATED MODULE: ./components/Layout/index.js



/***/ })

};
;